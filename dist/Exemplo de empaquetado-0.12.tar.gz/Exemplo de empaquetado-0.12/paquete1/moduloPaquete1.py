def imprimeAlgo ():
    print("Imprimo algo no paquete, e o seu nome: ",__name__)


def main():
    imprimeAlgo()

if __name__=="__main__":
    main()