def faiAlgo2 ():
    print("Imprimo algo no subpaquete, e o seu nome: ",__name__)